﻿<!DOCTYPE html>
<html>
<head>
<style type="text/CSS">
 body{
 font-family:"楷体";
 font-size:16px;
 font-style:normal;
 font-color:blue;
}
</style>
</head>
<body>
<div id=cl>
  <li><a href="chat.php">聊天社交</a></li>
  <li><a href="film.php">影视</a></li>
  <li><a href="game.php">游戏</a></li>
  <li><a href="work.php">实用工具</a></li>
  <li><a href="shopping.php">时尚购物</a></li>
</body>
